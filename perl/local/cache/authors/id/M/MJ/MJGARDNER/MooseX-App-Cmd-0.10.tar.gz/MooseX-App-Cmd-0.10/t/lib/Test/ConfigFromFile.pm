package Test::ConfigFromFile;
use Moose;

extends qw(MooseX::App::Cmd);

1;
